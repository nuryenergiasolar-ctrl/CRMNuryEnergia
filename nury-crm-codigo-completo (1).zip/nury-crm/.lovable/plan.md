# Migração do CRM Nury Energia para o GitHub (fora do Lovable Cloud)

Nada será alterado no sistema. Abaixo está o levantamento do que existe hoje e o passo a passo da migração.

## O que compõe o sistema hoje

**1. Aplicação (frontend + backend no mesmo projeto)**
Todo o código das telas está no projeto: Orçamentos (novo, tabela, pendentes, fechados, arquivados), Comercial/CRM (leads, pipeline/kanban, vendas, follow-ups, equipe, metas, produtos), Cobranças com calendário, Configurações, Login e o menu lateral. A parte de servidor é pequena: só o Conselho de IA roda no servidor.

**2. Banco de dados**
15 tabelas: orçamentos, histórico de orçamentos, leads, histórico de leads, follow-ups, cobranças, produtos, vendedores, metas, configurações, marketing/investimentos, integrações, papéis de usuário. Junto delas: as regras de acesso (quem vê o quê), os gatilhos que gravam histórico automaticamente e a numeração automática ORC-2026-0001. Existem 16 arquivos de migração que recriam toda essa estrutura do zero.

**3. Autenticação**
Login por e-mail/senha e Google. Os usuários já cadastrados ficam na área de autenticação do banco e precisam ser exportados junto (senhas incluídas), senão ninguém consegue entrar depois.

**4. Arquivos anexados**
Os PDFs e imagens dos orçamentos ficam num repositório de arquivos privado chamado "anexos", com regras de acesso próprias. Precisam ser baixados e recolocados no novo ambiente.

**5. Chaves e configurações**
Endereço do banco, chave pública, chave secreta de administração e a chave da IA (usada no Conselho Operacional). A chave da IA da Lovable **não funciona fora daqui** — é o único ponto que exige substituição.

## Plano passo a passo

**Passo 1 — Código no GitHub**
Conectar o projeto ao GitHub pelo botão do editor. Isso copia todo o código, incluindo os 16 arquivos de migração do banco. É o passo mais simples e não muda nada no sistema.

**Passo 2 — Criar sua própria conta de banco/autenticação**
Criar um projeto novo no Supabase (conta sua, plano gratuito serve para começar). Ele fornece banco, login e armazenamento de arquivos.

**Passo 3 — Recriar a estrutura do banco**
Rodar os arquivos de migração já existentes no projeto novo, em ordem. Isso recria tabelas, regras de acesso, gatilhos e numeração idênticas às atuais.

**Passo 4 — Copiar os dados**
Exportar os dados atuais (orçamentos, leads, cobranças, follow-ups, metas, configurações, histórico) e importar no projeto novo. Feito com um despejo do banco, mantendo os mesmos identificadores para não quebrar as ligações entre orçamento, histórico e cobranças.

**Passo 5 — Copiar os usuários**
Exportar os usuários e seus papéis (administrador/vendedor) e importar no novo projeto preservando as senhas. Depois, reativar o login por Google com credenciais próprias do Google Cloud.

**Passo 6 — Copiar os arquivos anexados**
Criar o repositório de arquivos "anexos" como privado, aplicar as mesmas regras de acesso e transferir todos os PDFs/imagens mantendo os mesmos caminhos, para que os links dentro dos orçamentos continuem abrindo.

**Passo 7 — Ajustar as chaves no novo ambiente**
Preencher endereço do banco e chaves do seu projeto. Para o Conselho de IA, contratar uma chave própria (OpenAI, Google Gemini ou OpenRouter) e apontar o sistema para ela — é uma troca de endereço e chave, sem mexer nas telas.

**Passo 8 — Publicar o site**
Publicar em Cloudflare Workers (alvo já usado hoje, caminho mais direto), Vercel ou Netlify, ligado ao repositório do GitHub. Apontar o domínio e testar: login, criar orçamento, anexar PDF, mover lead no kanban, cobranças e o Conselho de IA.

**Passo 9 — Desligar com segurança**
Só depois de tudo validado no ambiente novo, parar de usar este. Recomendo manter os dois no ar por alguns dias e registrar durante esse período apenas no ambiente novo, para não dividir informação.

## Detalhes técnicos

- Stack: TanStack Start v1 (React 19, Vite), Tailwind v4, shadcn/ui, TanStack Query. Nada proprietário nas telas.
- Acoplamento ao Lovable: `@lovable.dev/vite-tanstack-config` (devDependency) e `src/lib/lovable-error-reporting.ts`. O primeiro pode ser mantido como está ou substituído por uma config Vite explícita (tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro) — não é bloqueio.
- Chamada de IA: `src/lib/conselhos.functions.ts` + `src/lib/ai-gateway.server.ts` usam `https://ai.gateway.lovable.dev/v1` com `LOVABLE_API_KEY`. Trocar `baseURL`/header por provedor próprio (o cliente é OpenAI-compatible, então basta reconfigurar).
- Variáveis: `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_PROJECT_ID`, `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `LOVABLE_API_KEY`.
- Banco: `pg_dump` (schemas `public` + `auth`, com `--data-only` para os dados) ou `supabase db dump`. Storage: `supabase storage cp -r` entre projetos, bucket `anexos` privado.
- Ponto de atenção: as funções `meu_vendedor()` e `has_role()` sustentam as regras de acesso; a primeira liga o e-mail do login à linha em `vendedores`. Após importar usuários, conferir se os e-mails continuam idênticos.
- `supabase/config.toml` e os arquivos gerados em `src/integrations/supabase/` (client, types) apontam para o projeto atual e precisam ser regerados/reapontados no novo.

## Estimativa

Passos 1 a 3: rápido. Passos 4 a 6 (dados, usuários, arquivos): a parte mais delicada, exige cuidado com ordem e identificadores. Passos 7 e 8: configuração e testes. Total realista: um dia de trabalho técnico.
