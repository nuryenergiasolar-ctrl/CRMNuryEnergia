DROP POLICY IF EXISTS cobrancas_select ON public.cobrancas;
CREATE POLICY cobrancas_select ON public.cobrancas
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR (vendedor IS NOT NULL AND vendedor = public.meu_vendedor())
  OR (orcamento_id IS NOT NULL AND public.pode_ver_orcamento(orcamento_id))
);

DROP POLICY IF EXISTS followups_select ON public.follow_ups;
CREATE POLICY followups_select ON public.follow_ups
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR (lead_id IS NOT NULL AND public.pode_ver_lead(lead_id))
);

DROP POLICY IF EXISTS vendedores_select ON public.vendedores;
CREATE POLICY vendedores_select ON public.vendedores
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR lower(coalesce(email, '')) = lower(coalesce((auth.jwt() ->> 'email'), '@'))
);