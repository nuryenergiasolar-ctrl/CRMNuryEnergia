REVOKE EXECUTE ON FUNCTION public.set_orcamento_numero() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.log_orcamento_changes() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.log_orcamento_created() FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.orcamentos_touch_updated_at() FROM anon, authenticated, public;