ALTER TABLE public.orcamentos ADD COLUMN IF NOT EXISTS arquivado_em timestamp with time zone;

CREATE OR REPLACE FUNCTION public.log_orcamento_changes()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'status', OLD.status, NEW.status);
  END IF;
  IF NEW.responsavel IS DISTINCT FROM OLD.responsavel THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'responsavel', OLD.responsavel, NEW.responsavel);
  END IF;
  IF NEW.prioridade IS DISTINCT FROM OLD.prioridade THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'prioridade', OLD.prioridade, NEW.prioridade);
  END IF;
  IF NEW.prazo IS DISTINCT FROM OLD.prazo THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'prazo', OLD.prazo::text, NEW.prazo::text);
  END IF;
  IF NEW.arquivado_em IS DISTINCT FROM OLD.arquivado_em THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'arquivamento', CASE WHEN OLD.arquivado_em IS NULL THEN 'ativo' ELSE 'arquivado' END,
            CASE WHEN NEW.arquivado_em IS NULL THEN 'ativo' ELSE 'arquivado' END);
  END IF;
  RETURN NEW;
END;
$function$;