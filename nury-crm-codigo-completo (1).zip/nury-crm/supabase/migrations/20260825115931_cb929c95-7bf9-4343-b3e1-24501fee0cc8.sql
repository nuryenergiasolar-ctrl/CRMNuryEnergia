REVOKE ALL ON FUNCTION public.log_lead_changes() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_lead_created() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_orcamento_changes() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.log_orcamento_created() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_orcamento_numero() FROM PUBLIC, anon, authenticated;