-- LEADS
DROP POLICY IF EXISTS leads_insert ON public.leads;
DROP POLICY IF EXISTS leads_update ON public.leads;
CREATE POLICY leads_insert ON public.leads FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY leads_update ON public.leads FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ORCAMENTOS
DROP POLICY IF EXISTS orcamentos_insert ON public.orcamentos;
DROP POLICY IF EXISTS orcamentos_update ON public.orcamentos;
CREATE POLICY orcamentos_insert ON public.orcamentos FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY orcamentos_update ON public.orcamentos FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- PRODUTOS
DROP POLICY IF EXISTS produtos_insert ON public.produtos;
DROP POLICY IF EXISTS produtos_update ON public.produtos;
CREATE POLICY produtos_insert ON public.produtos FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY produtos_update ON public.produtos FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- VENDEDORES
DROP POLICY IF EXISTS vendedores_insert ON public.vendedores;
DROP POLICY IF EXISTS vendedores_update ON public.vendedores;
CREATE POLICY vendedores_insert ON public.vendedores FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY vendedores_update ON public.vendedores FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- FOLLOW UPS
DROP POLICY IF EXISTS followups_insert ON public.follow_ups;
DROP POLICY IF EXISTS followups_update ON public.follow_ups;
CREATE POLICY followups_insert ON public.follow_ups FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY followups_update ON public.follow_ups FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- HISTORICO (apenas admin insere manualmente; triggers do banco continuam funcionando)
DROP POLICY IF EXISTS lead_hist_insert ON public.lead_historico;
CREATE POLICY lead_hist_insert ON public.lead_historico FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
DROP POLICY IF EXISTS hist_insert ON public.orcamento_historico;
CREATE POLICY hist_insert ON public.orcamento_historico FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));