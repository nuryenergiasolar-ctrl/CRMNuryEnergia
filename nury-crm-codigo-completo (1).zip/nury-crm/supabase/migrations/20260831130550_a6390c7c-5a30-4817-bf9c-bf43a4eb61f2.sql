ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS endereco text;

COMMENT ON COLUMN public.leads.endereco IS 'Endereço completo do cliente';