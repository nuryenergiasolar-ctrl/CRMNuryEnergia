-- ORCAMENTOS: apenas autenticados
DROP POLICY IF EXISTS orcamentos_select ON public.orcamentos;
DROP POLICY IF EXISTS orcamentos_insert ON public.orcamentos;
DROP POLICY IF EXISTS orcamentos_update ON public.orcamentos;

REVOKE ALL ON public.orcamentos FROM anon;
GRANT SELECT, INSERT, UPDATE ON public.orcamentos TO authenticated;
GRANT ALL ON public.orcamentos TO service_role;

CREATE POLICY orcamentos_select ON public.orcamentos
  FOR SELECT TO authenticated USING (true);
CREATE POLICY orcamentos_insert ON public.orcamentos
  FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY orcamentos_update ON public.orcamentos
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

-- HISTORICO: apenas autenticados
DROP POLICY IF EXISTS hist_select ON public.orcamento_historico;
DROP POLICY IF EXISTS hist_insert ON public.orcamento_historico;

REVOKE ALL ON public.orcamento_historico FROM anon;
GRANT SELECT, INSERT ON public.orcamento_historico TO authenticated;
GRANT ALL ON public.orcamento_historico TO service_role;

CREATE POLICY hist_select ON public.orcamento_historico
  FOR SELECT TO authenticated USING (true);
CREATE POLICY hist_insert ON public.orcamento_historico
  FOR INSERT TO authenticated WITH CHECK (true);

-- STORAGE (bucket anexos): apenas autenticados
DROP POLICY IF EXISTS anexos_read ON storage.objects;
DROP POLICY IF EXISTS anexos_insert ON storage.objects;

CREATE POLICY anexos_read ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'anexos');
CREATE POLICY anexos_insert ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'anexos');