CREATE TABLE public.orcamentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  numero text NOT NULL UNIQUE,
  data_pedido timestamptz NOT NULL DEFAULT now(),
  cliente text NOT NULL,
  vendedor text NOT NULL,
  tipo text NOT NULL DEFAULT 'Solar',
  equipamento text,
  potencia text,
  prioridade text NOT NULL DEFAULT 'Normal',
  prazo date,
  responsavel text,
  status text NOT NULL DEFAULT 'Novo/Pendente',
  observacoes text,
  data_conclusao timestamptz,
  anexos jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.orcamentos TO anon, authenticated;
GRANT ALL ON public.orcamentos TO service_role;
ALTER TABLE public.orcamentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orcamentos_select" ON public.orcamentos FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "orcamentos_insert" ON public.orcamentos FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "orcamentos_update" ON public.orcamentos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.orcamento_historico (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  orcamento_id uuid NOT NULL REFERENCES public.orcamentos(id) ON DELETE CASCADE,
  campo text NOT NULL,
  valor_anterior text,
  valor_novo text,
  autor text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.orcamento_historico TO anon, authenticated;
GRANT ALL ON public.orcamento_historico TO service_role;
ALTER TABLE public.orcamento_historico ENABLE ROW LEVEL SECURITY;
CREATE POLICY "hist_select" ON public.orcamento_historico FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "hist_insert" ON public.orcamento_historico FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE INDEX idx_orcamentos_status ON public.orcamentos(status);
CREATE INDEX idx_orcamentos_prazo ON public.orcamentos(prazo);
CREATE INDEX idx_hist_orcamento ON public.orcamento_historico(orcamento_id);

CREATE SEQUENCE public.orcamento_numero_seq;
GRANT USAGE ON SEQUENCE public.orcamento_numero_seq TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.set_orcamento_numero()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.numero IS NULL OR NEW.numero = '' THEN
    NEW.numero := 'ORC-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.orcamento_numero_seq')::text, 4, '0');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_orcamento_numero BEFORE INSERT ON public.orcamentos
FOR EACH ROW EXECUTE FUNCTION public.set_orcamento_numero();

CREATE OR REPLACE FUNCTION public.orcamentos_touch_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_orcamentos_updated BEFORE UPDATE ON public.orcamentos
FOR EACH ROW EXECUTE FUNCTION public.orcamentos_touch_updated_at();

CREATE OR REPLACE FUNCTION public.log_orcamento_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'status', OLD.status, NEW.status);
  END IF;
  IF NEW.responsavel IS DISTINCT FROM OLD.responsavel THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'responsavel', OLD.responsavel, NEW.responsavel);
  END IF;
  IF NEW.prioridade IS DISTINCT FROM OLD.prioridade THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'prioridade', OLD.prioridade, NEW.prioridade);
  END IF;
  IF NEW.prazo IS DISTINCT FROM OLD.prazo THEN
    INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'prazo', OLD.prazo::text, NEW.prazo::text);
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_orcamento_hist AFTER UPDATE ON public.orcamentos
FOR EACH ROW EXECUTE FUNCTION public.log_orcamento_changes();

CREATE OR REPLACE FUNCTION public.log_orcamento_created()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.orcamento_historico (orcamento_id, campo, valor_anterior, valor_novo)
  VALUES (NEW.id, 'criacao', NULL, NEW.numero);
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_orcamento_created AFTER INSERT ON public.orcamentos
FOR EACH ROW EXECUTE FUNCTION public.log_orcamento_created();

CREATE POLICY "anexos_read" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'anexos');
CREATE POLICY "anexos_insert" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'anexos');