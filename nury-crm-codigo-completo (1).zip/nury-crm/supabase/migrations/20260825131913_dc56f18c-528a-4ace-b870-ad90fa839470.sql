CREATE TABLE public.cobrancas (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  orcamento_id uuid REFERENCES public.orcamentos(id) ON DELETE SET NULL,
  cliente text NOT NULL,
  telefone text,
  endereco text,
  vendedor text,
  tipo text,
  descricao text,
  valor numeric NOT NULL DEFAULT 0,
  parcela integer NOT NULL DEFAULT 1,
  total_parcelas integer NOT NULL DEFAULT 1,
  vencimento date NOT NULL DEFAULT CURRENT_DATE,
  pago boolean NOT NULL DEFAULT false,
  pago_em timestamp with time zone,
  forma_pagamento text,
  observacoes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cobrancas TO authenticated;
GRANT ALL ON public.cobrancas TO service_role;

ALTER TABLE public.cobrancas ENABLE ROW LEVEL SECURITY;

CREATE POLICY cobrancas_select ON public.cobrancas FOR SELECT TO authenticated USING (true);
CREATE POLICY cobrancas_insert ON public.cobrancas FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY cobrancas_update ON public.cobrancas FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY cobrancas_delete ON public.cobrancas FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE INDEX cobrancas_vencimento_idx ON public.cobrancas (vencimento);

CREATE TRIGGER trg_cobrancas_updated BEFORE UPDATE ON public.cobrancas
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();