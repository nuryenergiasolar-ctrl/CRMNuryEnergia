CREATE OR REPLACE FUNCTION public.meu_vendedor()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT v.nome
  FROM public.vendedores v
  WHERE lower(v.email) = lower(coalesce((auth.jwt() ->> 'email'), ''))
  LIMIT 1
$$;

REVOKE ALL ON FUNCTION public.meu_vendedor() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.meu_vendedor() TO authenticated;

CREATE OR REPLACE FUNCTION public.pode_ver_orcamento(_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'admin')
      OR EXISTS (
        SELECT 1 FROM public.orcamentos o
        WHERE o.id = _id AND o.vendedor = public.meu_vendedor()
      )
$$;

REVOKE ALL ON FUNCTION public.pode_ver_orcamento(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pode_ver_orcamento(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.pode_ver_lead(_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'admin')
      OR EXISTS (
        SELECT 1 FROM public.leads l
        WHERE l.id = _id AND l.vendedor = public.meu_vendedor()
      )
$$;

REVOKE ALL ON FUNCTION public.pode_ver_lead(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pode_ver_lead(uuid) TO authenticated;

-- Leads: admin vê tudo; demais apenas os próprios
DROP POLICY IF EXISTS leads_select ON public.leads;
CREATE POLICY leads_select ON public.leads
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR (vendedor IS NOT NULL AND vendedor = public.meu_vendedor())
);

DROP POLICY IF EXISTS lead_hist_select ON public.lead_historico;
CREATE POLICY lead_hist_select ON public.lead_historico
FOR SELECT TO authenticated
USING (public.pode_ver_lead(lead_id));

-- Orçamentos: admin vê tudo; demais apenas os próprios
DROP POLICY IF EXISTS orcamentos_select ON public.orcamentos;
CREATE POLICY orcamentos_select ON public.orcamentos
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR vendedor = public.meu_vendedor()
);

DROP POLICY IF EXISTS hist_select ON public.orcamento_historico;
CREATE POLICY hist_select ON public.orcamento_historico
FOR SELECT TO authenticated
USING (public.pode_ver_orcamento(orcamento_id));

-- Storage: anexos ligados a um orçamento visível; escrita apenas admin
DROP POLICY IF EXISTS anexos_read ON storage.objects;
DROP POLICY IF EXISTS anexos_insert ON storage.objects;
DROP POLICY IF EXISTS anexos_update ON storage.objects;
DROP POLICY IF EXISTS anexos_delete ON storage.objects;

CREATE POLICY anexos_read ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'anexos'
  AND (
    public.has_role(auth.uid(), 'admin')
    OR EXISTS (
      SELECT 1
      FROM public.orcamentos o,
           LATERAL jsonb_array_elements(o.anexos) a
      WHERE a ->> 'caminho' = storage.objects.name
        AND o.vendedor = public.meu_vendedor()
    )
  )
);

CREATE POLICY anexos_insert ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'anexos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY anexos_update ON storage.objects
FOR UPDATE TO authenticated
USING (bucket_id = 'anexos' AND public.has_role(auth.uid(), 'admin'))
WITH CHECK (bucket_id = 'anexos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY anexos_delete ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'anexos' AND public.has_role(auth.uid(), 'admin'));