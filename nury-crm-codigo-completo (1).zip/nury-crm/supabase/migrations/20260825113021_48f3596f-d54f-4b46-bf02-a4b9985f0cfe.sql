-- ROLES
CREATE TYPE public.app_role AS ENUM ('admin', 'vendedor');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "roles_select_own" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END;
$$;

-- PRODUTOS
CREATE TABLE public.produtos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  categoria text NOT NULL DEFAULT 'Solar',
  preco_base numeric(14,2),
  descricao text,
  ativo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.produtos TO authenticated;
GRANT ALL ON public.produtos TO service_role;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "produtos_select" ON public.produtos FOR SELECT TO authenticated USING (true);
CREATE POLICY "produtos_insert" ON public.produtos FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "produtos_update" ON public.produtos FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_produtos_updated BEFORE UPDATE ON public.produtos FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- VENDEDORES
CREATE TABLE public.vendedores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  email text,
  telefone text,
  meta_mensal numeric(14,2),
  ativo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vendedores TO authenticated;
GRANT ALL ON public.vendedores TO service_role;
ALTER TABLE public.vendedores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vendedores_select" ON public.vendedores FOR SELECT TO authenticated USING (true);
CREATE POLICY "vendedores_insert" ON public.vendedores FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "vendedores_update" ON public.vendedores FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_vendedores_updated BEFORE UPDATE ON public.vendedores FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- LEADS
CREATE TABLE public.leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  telefone text,
  email text,
  cidade text,
  origem text NOT NULL DEFAULT 'WhatsApp',
  tipo text NOT NULL DEFAULT 'Residencial',
  temperatura text NOT NULL DEFAULT 'Morno',
  produto_id uuid REFERENCES public.produtos(id) ON DELETE SET NULL,
  produto text,
  vendedor text,
  etapa text NOT NULL DEFAULT 'Novo lead',
  valor numeric(14,2),
  campanha text,
  motivo_perda text,
  observacoes text,
  data_entrada timestamptz NOT NULL DEFAULT now(),
  data_fechamento timestamptz,
  ultimo_contato timestamptz,
  arquivado_em timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.leads TO authenticated;
GRANT ALL ON public.leads TO service_role;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leads_select" ON public.leads FOR SELECT TO authenticated USING (true);
CREATE POLICY "leads_insert" ON public.leads FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "leads_update" ON public.leads FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_leads_updated BEFORE UPDATE ON public.leads FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- HISTORICO
CREATE TABLE public.lead_historico (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  campo text NOT NULL,
  valor_anterior text,
  valor_novo text,
  autor text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.lead_historico TO authenticated;
GRANT ALL ON public.lead_historico TO service_role;
ALTER TABLE public.lead_historico ENABLE ROW LEVEL SECURITY;
CREATE POLICY "lead_hist_select" ON public.lead_historico FOR SELECT TO authenticated USING (true);
CREATE POLICY "lead_hist_insert" ON public.lead_historico FOR INSERT TO authenticated WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.log_lead_created()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo)
  VALUES (NEW.id, 'criacao', NULL, NEW.nome);
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.log_lead_created() FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.log_lead_changes()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.etapa IS DISTINCT FROM OLD.etapa THEN
    INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo) VALUES (NEW.id, 'etapa', OLD.etapa, NEW.etapa);
  END IF;
  IF NEW.vendedor IS DISTINCT FROM OLD.vendedor THEN
    INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo) VALUES (NEW.id, 'vendedor', OLD.vendedor, NEW.vendedor);
  END IF;
  IF NEW.temperatura IS DISTINCT FROM OLD.temperatura THEN
    INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo) VALUES (NEW.id, 'temperatura', OLD.temperatura, NEW.temperatura);
  END IF;
  IF NEW.valor IS DISTINCT FROM OLD.valor THEN
    INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo) VALUES (NEW.id, 'valor', OLD.valor::text, NEW.valor::text);
  END IF;
  IF NEW.motivo_perda IS DISTINCT FROM OLD.motivo_perda THEN
    INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo) VALUES (NEW.id, 'motivo_perda', OLD.motivo_perda, NEW.motivo_perda);
  END IF;
  IF NEW.arquivado_em IS DISTINCT FROM OLD.arquivado_em THEN
    INSERT INTO public.lead_historico (lead_id, campo, valor_anterior, valor_novo)
    VALUES (NEW.id, 'arquivamento', CASE WHEN OLD.arquivado_em IS NULL THEN 'ativo' ELSE 'arquivado' END,
            CASE WHEN NEW.arquivado_em IS NULL THEN 'ativo' ELSE 'arquivado' END);
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.log_lead_changes() FROM anon, authenticated;

CREATE TRIGGER trg_lead_created AFTER INSERT ON public.leads FOR EACH ROW EXECUTE FUNCTION public.log_lead_created();
CREATE TRIGGER trg_lead_changes AFTER UPDATE ON public.leads FOR EACH ROW EXECUTE FUNCTION public.log_lead_changes();

-- FOLLOW UPS
CREATE TABLE public.follow_ups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES public.leads(id) ON DELETE CASCADE,
  titulo text NOT NULL,
  tipo text NOT NULL DEFAULT 'WhatsApp',
  responsavel text,
  data_prevista timestamptz NOT NULL DEFAULT now(),
  concluido boolean NOT NULL DEFAULT false,
  concluido_em timestamptz,
  observacoes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.follow_ups TO authenticated;
GRANT ALL ON public.follow_ups TO service_role;
ALTER TABLE public.follow_ups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "followups_select" ON public.follow_ups FOR SELECT TO authenticated USING (true);
CREATE POLICY "followups_insert" ON public.follow_ups FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "followups_update" ON public.follow_ups FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trg_followups_updated BEFORE UPDATE ON public.follow_ups FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- MARKETING (ADMIN ONLY)
CREATE TABLE public.marketing_investimentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canal text NOT NULL DEFAULT 'Instagram Ads',
  campanha text,
  data_inicio date NOT NULL DEFAULT current_date,
  data_fim date,
  valor numeric(14,2) NOT NULL DEFAULT 0,
  impressoes integer NOT NULL DEFAULT 0,
  cliques integer NOT NULL DEFAULT 0,
  leads_gerados integer NOT NULL DEFAULT 0,
  observacoes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.marketing_investimentos TO authenticated;
GRANT ALL ON public.marketing_investimentos TO service_role;
ALTER TABLE public.marketing_investimentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "mkt_admin_all" ON public.marketing_investimentos FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER trg_mkt_updated BEFORE UPDATE ON public.marketing_investimentos FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- INTEGRACOES (ADMIN ONLY)
CREATE TABLE public.integracoes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canal text NOT NULL UNIQUE,
  ativo boolean NOT NULL DEFAULT false,
  identificador text,
  observacoes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.integracoes TO authenticated;
GRANT ALL ON public.integracoes TO service_role;
ALTER TABLE public.integracoes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "integracoes_admin_all" ON public.integracoes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE TRIGGER trg_integracoes_updated BEFORE UPDATE ON public.integracoes FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- SEED
INSERT INTO public.produtos (nome, categoria, preco_base) VALUES
  ('Sistema Solar', 'Solar', 30000),
  ('Carregador 7kW', 'Carregador Veicular', 7000),
  ('Carregador 22kW', 'Carregador Veicular', 20000),
  ('BESS', 'BESS', 68000),
  ('Usina de Investimento', 'Usina de Investimento', 100000);

INSERT INTO public.vendedores (nome, meta_mensal) VALUES
  ('Yasmin', 400000), ('Mauro', 350000), ('Vander', 250000), ('Rodrigo', 200000), ('Vinicius', 150000);

INSERT INTO public.integracoes (canal, ativo) VALUES
  ('WhatsApp', false), ('Facebook / Instagram', false), ('Tráfego pago', false);
